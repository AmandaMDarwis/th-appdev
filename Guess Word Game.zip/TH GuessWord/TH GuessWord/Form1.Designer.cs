﻿namespace TH_GuessWord
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbWord1 = new System.Windows.Forms.TextBox();
            this.tbWord2 = new System.Windows.Forms.TextBox();
            this.tbWord3 = new System.Windows.Forms.TextBox();
            this.tbWord4 = new System.Windows.Forms.TextBox();
            this.tbWord5 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.PlayButton = new System.Windows.Forms.Button();
            this.panelInput = new System.Windows.Forms.Panel();
            this.buttonQ = new System.Windows.Forms.Button();
            this.buttonW = new System.Windows.Forms.Button();
            this.buttonE = new System.Windows.Forms.Button();
            this.buttonR = new System.Windows.Forms.Button();
            this.buttonT = new System.Windows.Forms.Button();
            this.buttonY = new System.Windows.Forms.Button();
            this.buttonU = new System.Windows.Forms.Button();
            this.buttonI = new System.Windows.Forms.Button();
            this.buttonO = new System.Windows.Forms.Button();
            this.buttonA = new System.Windows.Forms.Button();
            this.buttonP = new System.Windows.Forms.Button();
            this.buttonS = new System.Windows.Forms.Button();
            this.buttonD = new System.Windows.Forms.Button();
            this.buttonF = new System.Windows.Forms.Button();
            this.buttonG = new System.Windows.Forms.Button();
            this.buttonH = new System.Windows.Forms.Button();
            this.buttonJ = new System.Windows.Forms.Button();
            this.buttonK = new System.Windows.Forms.Button();
            this.buttonN = new System.Windows.Forms.Button();
            this.buttonB = new System.Windows.Forms.Button();
            this.buttonV = new System.Windows.Forms.Button();
            this.buttonC = new System.Windows.Forms.Button();
            this.buttonX = new System.Windows.Forms.Button();
            this.buttonZ = new System.Windows.Forms.Button();
            this.labelGuess = new System.Windows.Forms.Label();
            this.buttonL = new System.Windows.Forms.Button();
            this.buttonM = new System.Windows.Forms.Button();
            this.panelPlayingBoard = new System.Windows.Forms.Panel();
            this.labelChosenWrd = new System.Windows.Forms.Label();
            this.panelInput.SuspendLayout();
            this.panelPlayingBoard.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbWord1
            // 
            this.tbWord1.Location = new System.Drawing.Point(93, 13);
            this.tbWord1.Name = "tbWord1";
            this.tbWord1.Size = new System.Drawing.Size(156, 22);
            this.tbWord1.TabIndex = 0;
            // 
            // tbWord2
            // 
            this.tbWord2.Location = new System.Drawing.Point(93, 67);
            this.tbWord2.Name = "tbWord2";
            this.tbWord2.Size = new System.Drawing.Size(156, 22);
            this.tbWord2.TabIndex = 1;
            // 
            // tbWord3
            // 
            this.tbWord3.Location = new System.Drawing.Point(93, 125);
            this.tbWord3.Name = "tbWord3";
            this.tbWord3.Size = new System.Drawing.Size(156, 22);
            this.tbWord3.TabIndex = 2;
            // 
            // tbWord4
            // 
            this.tbWord4.Location = new System.Drawing.Point(93, 186);
            this.tbWord4.Name = "tbWord4";
            this.tbWord4.Size = new System.Drawing.Size(156, 22);
            this.tbWord4.TabIndex = 3;
            // 
            // tbWord5
            // 
            this.tbWord5.Location = new System.Drawing.Point(93, 244);
            this.tbWord5.Name = "tbWord5";
            this.tbWord5.Size = new System.Drawing.Size(156, 22);
            this.tbWord5.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 16);
            this.label1.TabIndex = 5;
            this.label1.Text = "Word 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "Word 2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 16);
            this.label3.TabIndex = 7;
            this.label3.Text = "Word 3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 186);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = "Word 4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 244);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 16);
            this.label5.TabIndex = 9;
            this.label5.Text = "Word 5";
            // 
            // PlayButton
            // 
            this.PlayButton.Location = new System.Drawing.Point(131, 292);
            this.PlayButton.Name = "PlayButton";
            this.PlayButton.Size = new System.Drawing.Size(73, 32);
            this.PlayButton.TabIndex = 10;
            this.PlayButton.Text = "Play";
            this.PlayButton.UseVisualStyleBackColor = true;
            this.PlayButton.Click += new System.EventHandler(this.PlayButton_Click);
            // 
            // panelInput
            // 
            this.panelInput.Controls.Add(this.tbWord1);
            this.panelInput.Controls.Add(this.PlayButton);
            this.panelInput.Controls.Add(this.tbWord2);
            this.panelInput.Controls.Add(this.label5);
            this.panelInput.Controls.Add(this.tbWord3);
            this.panelInput.Controls.Add(this.label4);
            this.panelInput.Controls.Add(this.tbWord4);
            this.panelInput.Controls.Add(this.label3);
            this.panelInput.Controls.Add(this.tbWord5);
            this.panelInput.Controls.Add(this.label2);
            this.panelInput.Controls.Add(this.label1);
            this.panelInput.Location = new System.Drawing.Point(56, 63);
            this.panelInput.Name = "panelInput";
            this.panelInput.Size = new System.Drawing.Size(263, 332);
            this.panelInput.TabIndex = 11;
            // 
            // buttonQ
            // 
            this.buttonQ.Font = new System.Drawing.Font("Malgun Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonQ.Location = new System.Drawing.Point(90, 148);
            this.buttonQ.Name = "buttonQ";
            this.buttonQ.Size = new System.Drawing.Size(75, 66);
            this.buttonQ.TabIndex = 12;
            this.buttonQ.Text = "Q";
            this.buttonQ.UseVisualStyleBackColor = true;
            this.buttonQ.Click += new System.EventHandler(this.buttonQ_Click);
            // 
            // buttonW
            // 
            this.buttonW.Font = new System.Drawing.Font("Malgun Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonW.Location = new System.Drawing.Point(171, 148);
            this.buttonW.Name = "buttonW";
            this.buttonW.Size = new System.Drawing.Size(75, 66);
            this.buttonW.TabIndex = 13;
            this.buttonW.Text = "W";
            this.buttonW.UseVisualStyleBackColor = true;
            this.buttonW.Click += new System.EventHandler(this.buttonW_Click);
            // 
            // buttonE
            // 
            this.buttonE.Font = new System.Drawing.Font("Malgun Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonE.Location = new System.Drawing.Point(252, 148);
            this.buttonE.Name = "buttonE";
            this.buttonE.Size = new System.Drawing.Size(75, 66);
            this.buttonE.TabIndex = 14;
            this.buttonE.Text = "E";
            this.buttonE.UseVisualStyleBackColor = true;
            this.buttonE.Click += new System.EventHandler(this.buttonE_Click);
            // 
            // buttonR
            // 
            this.buttonR.Font = new System.Drawing.Font("Malgun Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonR.Location = new System.Drawing.Point(333, 148);
            this.buttonR.Name = "buttonR";
            this.buttonR.Size = new System.Drawing.Size(75, 66);
            this.buttonR.TabIndex = 15;
            this.buttonR.Text = "R";
            this.buttonR.UseVisualStyleBackColor = true;
            this.buttonR.Click += new System.EventHandler(this.buttonR_Click);
            // 
            // buttonT
            // 
            this.buttonT.Font = new System.Drawing.Font("Malgun Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonT.Location = new System.Drawing.Point(414, 148);
            this.buttonT.Name = "buttonT";
            this.buttonT.Size = new System.Drawing.Size(75, 66);
            this.buttonT.TabIndex = 16;
            this.buttonT.Text = "T";
            this.buttonT.UseVisualStyleBackColor = true;
            this.buttonT.Click += new System.EventHandler(this.buttonT_Click);
            // 
            // buttonY
            // 
            this.buttonY.Font = new System.Drawing.Font("Malgun Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonY.Location = new System.Drawing.Point(495, 148);
            this.buttonY.Name = "buttonY";
            this.buttonY.Size = new System.Drawing.Size(75, 66);
            this.buttonY.TabIndex = 17;
            this.buttonY.Text = "Y";
            this.buttonY.UseVisualStyleBackColor = true;
            this.buttonY.Click += new System.EventHandler(this.buttonY_Click);
            // 
            // buttonU
            // 
            this.buttonU.Font = new System.Drawing.Font("Malgun Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonU.Location = new System.Drawing.Point(576, 148);
            this.buttonU.Name = "buttonU";
            this.buttonU.Size = new System.Drawing.Size(75, 66);
            this.buttonU.TabIndex = 18;
            this.buttonU.Text = "U";
            this.buttonU.UseVisualStyleBackColor = true;
            this.buttonU.Click += new System.EventHandler(this.buttonU_Click);
            // 
            // buttonI
            // 
            this.buttonI.Font = new System.Drawing.Font("Malgun Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonI.Location = new System.Drawing.Point(657, 148);
            this.buttonI.Name = "buttonI";
            this.buttonI.Size = new System.Drawing.Size(75, 66);
            this.buttonI.TabIndex = 19;
            this.buttonI.Text = "I";
            this.buttonI.UseVisualStyleBackColor = true;
            this.buttonI.Click += new System.EventHandler(this.buttonI_Click);
            // 
            // buttonO
            // 
            this.buttonO.Font = new System.Drawing.Font("Malgun Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonO.Location = new System.Drawing.Point(738, 148);
            this.buttonO.Name = "buttonO";
            this.buttonO.Size = new System.Drawing.Size(75, 66);
            this.buttonO.TabIndex = 20;
            this.buttonO.Text = "O";
            this.buttonO.UseVisualStyleBackColor = true;
            this.buttonO.Click += new System.EventHandler(this.buttonO_Click);
            // 
            // buttonA
            // 
            this.buttonA.Font = new System.Drawing.Font("Malgun Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonA.Location = new System.Drawing.Point(134, 220);
            this.buttonA.Name = "buttonA";
            this.buttonA.Size = new System.Drawing.Size(75, 66);
            this.buttonA.TabIndex = 21;
            this.buttonA.Text = "A";
            this.buttonA.UseVisualStyleBackColor = true;
            this.buttonA.Click += new System.EventHandler(this.buttonA_Click);
            // 
            // buttonP
            // 
            this.buttonP.Font = new System.Drawing.Font("Malgun Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonP.Location = new System.Drawing.Point(819, 148);
            this.buttonP.Name = "buttonP";
            this.buttonP.Size = new System.Drawing.Size(75, 66);
            this.buttonP.TabIndex = 22;
            this.buttonP.Text = "P";
            this.buttonP.UseVisualStyleBackColor = true;
            this.buttonP.Click += new System.EventHandler(this.buttonP_Click);
            // 
            // buttonS
            // 
            this.buttonS.Font = new System.Drawing.Font("Malgun Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonS.Location = new System.Drawing.Point(215, 220);
            this.buttonS.Name = "buttonS";
            this.buttonS.Size = new System.Drawing.Size(75, 66);
            this.buttonS.TabIndex = 23;
            this.buttonS.Text = "S";
            this.buttonS.UseVisualStyleBackColor = true;
            this.buttonS.Click += new System.EventHandler(this.buttonS_Click);
            // 
            // buttonD
            // 
            this.buttonD.Font = new System.Drawing.Font("Malgun Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonD.Location = new System.Drawing.Point(296, 220);
            this.buttonD.Name = "buttonD";
            this.buttonD.Size = new System.Drawing.Size(75, 66);
            this.buttonD.TabIndex = 24;
            this.buttonD.Text = "D";
            this.buttonD.UseVisualStyleBackColor = true;
            this.buttonD.Click += new System.EventHandler(this.buttonD_Click);
            // 
            // buttonF
            // 
            this.buttonF.Font = new System.Drawing.Font("Malgun Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonF.Location = new System.Drawing.Point(377, 220);
            this.buttonF.Name = "buttonF";
            this.buttonF.Size = new System.Drawing.Size(75, 66);
            this.buttonF.TabIndex = 25;
            this.buttonF.Text = "F";
            this.buttonF.UseVisualStyleBackColor = true;
            this.buttonF.Click += new System.EventHandler(this.buttonF_Click);
            // 
            // buttonG
            // 
            this.buttonG.Font = new System.Drawing.Font("Malgun Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonG.Location = new System.Drawing.Point(458, 220);
            this.buttonG.Name = "buttonG";
            this.buttonG.Size = new System.Drawing.Size(75, 66);
            this.buttonG.TabIndex = 26;
            this.buttonG.Text = "G";
            this.buttonG.UseVisualStyleBackColor = true;
            this.buttonG.Click += new System.EventHandler(this.buttonG_Click);
            // 
            // buttonH
            // 
            this.buttonH.Font = new System.Drawing.Font("Malgun Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonH.Location = new System.Drawing.Point(539, 220);
            this.buttonH.Name = "buttonH";
            this.buttonH.Size = new System.Drawing.Size(75, 66);
            this.buttonH.TabIndex = 27;
            this.buttonH.Text = "H";
            this.buttonH.UseVisualStyleBackColor = true;
            this.buttonH.Click += new System.EventHandler(this.buttonH_Click);
            // 
            // buttonJ
            // 
            this.buttonJ.Font = new System.Drawing.Font("Malgun Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonJ.Location = new System.Drawing.Point(620, 220);
            this.buttonJ.Name = "buttonJ";
            this.buttonJ.Size = new System.Drawing.Size(75, 66);
            this.buttonJ.TabIndex = 28;
            this.buttonJ.Text = "J";
            this.buttonJ.UseVisualStyleBackColor = true;
            this.buttonJ.Click += new System.EventHandler(this.buttonJ_Click);
            // 
            // buttonK
            // 
            this.buttonK.Font = new System.Drawing.Font("Malgun Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonK.Location = new System.Drawing.Point(701, 220);
            this.buttonK.Name = "buttonK";
            this.buttonK.Size = new System.Drawing.Size(75, 66);
            this.buttonK.TabIndex = 29;
            this.buttonK.Text = "K";
            this.buttonK.UseVisualStyleBackColor = true;
            this.buttonK.Click += new System.EventHandler(this.buttonK_Click);
            // 
            // buttonN
            // 
            this.buttonN.Font = new System.Drawing.Font("Malgun Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonN.Location = new System.Drawing.Point(620, 292);
            this.buttonN.Name = "buttonN";
            this.buttonN.Size = new System.Drawing.Size(75, 66);
            this.buttonN.TabIndex = 30;
            this.buttonN.Text = "N";
            this.buttonN.UseVisualStyleBackColor = true;
            this.buttonN.Click += new System.EventHandler(this.buttonN_Click);
            // 
            // buttonB
            // 
            this.buttonB.Font = new System.Drawing.Font("Malgun Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonB.Location = new System.Drawing.Point(539, 292);
            this.buttonB.Name = "buttonB";
            this.buttonB.Size = new System.Drawing.Size(75, 66);
            this.buttonB.TabIndex = 31;
            this.buttonB.Text = "B";
            this.buttonB.UseVisualStyleBackColor = true;
            this.buttonB.Click += new System.EventHandler(this.buttonB_Click);
            // 
            // buttonV
            // 
            this.buttonV.Font = new System.Drawing.Font("Malgun Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonV.Location = new System.Drawing.Point(458, 292);
            this.buttonV.Name = "buttonV";
            this.buttonV.Size = new System.Drawing.Size(75, 66);
            this.buttonV.TabIndex = 32;
            this.buttonV.Text = "V";
            this.buttonV.UseVisualStyleBackColor = true;
            this.buttonV.Click += new System.EventHandler(this.buttonV_Click);
            // 
            // buttonC
            // 
            this.buttonC.Font = new System.Drawing.Font("Malgun Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonC.Location = new System.Drawing.Point(377, 292);
            this.buttonC.Name = "buttonC";
            this.buttonC.Size = new System.Drawing.Size(75, 66);
            this.buttonC.TabIndex = 33;
            this.buttonC.Text = "C";
            this.buttonC.UseVisualStyleBackColor = true;
            this.buttonC.Click += new System.EventHandler(this.buttonC_Click);
            // 
            // buttonX
            // 
            this.buttonX.Font = new System.Drawing.Font("Malgun Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonX.Location = new System.Drawing.Point(296, 292);
            this.buttonX.Name = "buttonX";
            this.buttonX.Size = new System.Drawing.Size(75, 66);
            this.buttonX.TabIndex = 34;
            this.buttonX.Text = "X";
            this.buttonX.UseVisualStyleBackColor = true;
            this.buttonX.Click += new System.EventHandler(this.buttonX_Click);
            // 
            // buttonZ
            // 
            this.buttonZ.Font = new System.Drawing.Font("Malgun Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonZ.Location = new System.Drawing.Point(215, 292);
            this.buttonZ.Name = "buttonZ";
            this.buttonZ.Size = new System.Drawing.Size(75, 66);
            this.buttonZ.TabIndex = 35;
            this.buttonZ.Text = "Z";
            this.buttonZ.UseVisualStyleBackColor = true;
            this.buttonZ.Click += new System.EventHandler(this.buttonZ_Click);
            // 
            // labelGuess
            // 
            this.labelGuess.AutoSize = true;
            this.labelGuess.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGuess.Location = new System.Drawing.Point(364, 36);
            this.labelGuess.Name = "labelGuess";
            this.labelGuess.Size = new System.Drawing.Size(259, 69);
            this.labelGuess.TabIndex = 36;
            this.labelGuess.Text = "_ _ _ _ _";
            // 
            // buttonL
            // 
            this.buttonL.Font = new System.Drawing.Font("Malgun Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonL.Location = new System.Drawing.Point(782, 220);
            this.buttonL.Name = "buttonL";
            this.buttonL.Size = new System.Drawing.Size(75, 66);
            this.buttonL.TabIndex = 37;
            this.buttonL.Text = "L";
            this.buttonL.UseVisualStyleBackColor = true;
            this.buttonL.Click += new System.EventHandler(this.buttonL_Click);
            // 
            // buttonM
            // 
            this.buttonM.Font = new System.Drawing.Font("Malgun Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonM.Location = new System.Drawing.Point(701, 292);
            this.buttonM.Name = "buttonM";
            this.buttonM.Size = new System.Drawing.Size(75, 66);
            this.buttonM.TabIndex = 38;
            this.buttonM.Text = "M";
            this.buttonM.UseVisualStyleBackColor = true;
            this.buttonM.Click += new System.EventHandler(this.buttonM_Click);
            // 
            // panelPlayingBoard
            // 
            this.panelPlayingBoard.Controls.Add(this.labelChosenWrd);
            this.panelPlayingBoard.Controls.Add(this.labelGuess);
            this.panelPlayingBoard.Controls.Add(this.buttonM);
            this.panelPlayingBoard.Controls.Add(this.buttonQ);
            this.panelPlayingBoard.Controls.Add(this.buttonL);
            this.panelPlayingBoard.Controls.Add(this.buttonW);
            this.panelPlayingBoard.Controls.Add(this.buttonE);
            this.panelPlayingBoard.Controls.Add(this.buttonZ);
            this.panelPlayingBoard.Controls.Add(this.buttonR);
            this.panelPlayingBoard.Controls.Add(this.buttonX);
            this.panelPlayingBoard.Controls.Add(this.buttonT);
            this.panelPlayingBoard.Controls.Add(this.buttonC);
            this.panelPlayingBoard.Controls.Add(this.buttonY);
            this.panelPlayingBoard.Controls.Add(this.buttonV);
            this.panelPlayingBoard.Controls.Add(this.buttonU);
            this.panelPlayingBoard.Controls.Add(this.buttonB);
            this.panelPlayingBoard.Controls.Add(this.buttonI);
            this.panelPlayingBoard.Controls.Add(this.buttonN);
            this.panelPlayingBoard.Controls.Add(this.buttonO);
            this.panelPlayingBoard.Controls.Add(this.buttonK);
            this.panelPlayingBoard.Controls.Add(this.buttonA);
            this.panelPlayingBoard.Controls.Add(this.buttonJ);
            this.panelPlayingBoard.Controls.Add(this.buttonP);
            this.panelPlayingBoard.Controls.Add(this.buttonH);
            this.panelPlayingBoard.Controls.Add(this.buttonS);
            this.panelPlayingBoard.Controls.Add(this.buttonG);
            this.panelPlayingBoard.Controls.Add(this.buttonD);
            this.panelPlayingBoard.Controls.Add(this.buttonF);
            this.panelPlayingBoard.Location = new System.Drawing.Point(126, 40);
            this.panelPlayingBoard.Name = "panelPlayingBoard";
            this.panelPlayingBoard.Size = new System.Drawing.Size(976, 397);
            this.panelPlayingBoard.TabIndex = 39;
            // 
            // labelChosenWrd
            // 
            this.labelChosenWrd.AutoSize = true;
            this.labelChosenWrd.Location = new System.Drawing.Point(759, 36);
            this.labelChosenWrd.Name = "labelChosenWrd";
            this.labelChosenWrd.Size = new System.Drawing.Size(0, 16);
            this.labelChosenWrd.TabIndex = 39;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1240, 562);
            this.Controls.Add(this.panelPlayingBoard);
            this.Controls.Add(this.panelInput);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panelInput.ResumeLayout(false);
            this.panelInput.PerformLayout();
            this.panelPlayingBoard.ResumeLayout(false);
            this.panelPlayingBoard.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox tbWord1;
        private System.Windows.Forms.TextBox tbWord2;
        private System.Windows.Forms.TextBox tbWord3;
        private System.Windows.Forms.TextBox tbWord4;
        private System.Windows.Forms.TextBox tbWord5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button PlayButton;
        private System.Windows.Forms.Panel panelInput;
        private System.Windows.Forms.Button buttonQ;
        private System.Windows.Forms.Button buttonW;
        private System.Windows.Forms.Button buttonE;
        private System.Windows.Forms.Button buttonR;
        private System.Windows.Forms.Button buttonT;
        private System.Windows.Forms.Button buttonY;
        private System.Windows.Forms.Button buttonU;
        private System.Windows.Forms.Button buttonI;
        private System.Windows.Forms.Button buttonO;
        private System.Windows.Forms.Button buttonA;
        private System.Windows.Forms.Button buttonP;
        private System.Windows.Forms.Button buttonS;
        private System.Windows.Forms.Button buttonD;
        private System.Windows.Forms.Button buttonF;
        private System.Windows.Forms.Button buttonG;
        private System.Windows.Forms.Button buttonH;
        private System.Windows.Forms.Button buttonJ;
        private System.Windows.Forms.Button buttonK;
        private System.Windows.Forms.Button buttonN;
        private System.Windows.Forms.Button buttonB;
        private System.Windows.Forms.Button buttonV;
        private System.Windows.Forms.Button buttonC;
        private System.Windows.Forms.Button buttonX;
        private System.Windows.Forms.Button buttonZ;
        private System.Windows.Forms.Label labelGuess;
        private System.Windows.Forms.Button buttonL;
        private System.Windows.Forms.Button buttonM;
        private System.Windows.Forms.Panel panelPlayingBoard;
        private System.Windows.Forms.Label labelChosenWrd;
    }
}

