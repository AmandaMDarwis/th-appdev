﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH_GuessWord
{
    public partial class Form1 : Form
    {
        string chosenWord = "";
        string guessed = "";
        public Form1()
        {
            InitializeComponent();
            panelPlayingBoard.Visible = false;
        }

        private void PlayButton_Click(object sender, EventArgs e)
        {
            bool wordInList = false;
            List<string> input = new List<string>();
            if (tbWord1.Text != null && tbWord2!=null && tbWord3!=null && tbWord4!=null && tbWord5 != null)
            {
                input.Add(tbWord1.Text); 
                input.Add(tbWord2.Text); 
                input.Add(tbWord3.Text); 
                input.Add(tbWord4.Text); 
                input.Add(tbWord5.Text);

                
                for (int i = 0; i < input.Count; i++)
                {
                    string tempWord = input[i];

                    input.RemoveAt(i);

                    wordInList = input.Contains(tempWord);

                    if (wordInList == true)
                    {
                        MessageBox.Show("Ada kata yang sama. Tolong diubah !");
                        input = new List<string>();
                        break;
                    }

                    input.Insert(i, tempWord);
                }

                if (wordInList == false)
                {
                    bool lengthIs5 = false;
                    for (int i = 0; i < input.Count; i++)
                    {
                        if (input[i].Length != 5) 
                        {
                            lengthIs5 = false;
                            MessageBox.Show("Kata tidak boleh lebih dari / kurang dari 5 huruf");
                            input = new List<string>();
                            break;
                        }
                        else
                        {
                            lengthIs5 = true;
                        }
                        
                    }
                    
                    if (lengthIs5 == true)
                    {
                        bool hasNumber = false;
                        foreach (string kata in input)
                        {
                            hasNumber = CheckNumber(kata);

                            if (hasNumber == true)
                            {
                                MessageBox.Show("Tidak boleh ada angka di dalam kata !");
                                input = new List<string>();
                                break;
                            }
                            
                        }

                        if (hasNumber == false)
                        {
                            panelInput.Visible = false;
                            panelPlayingBoard.Visible = true;
                            Random rnd = new Random();
                            int randomWord = rnd.Next(5);
                            chosenWord = input[randomWord].ToLower();
                            //labelChosenWrd.Text = chosenWord;
                        }
                        
                    }
                }
                
            }
            else
            {
                MessageBox.Show("Input masih ada yang kosong!");
            }

            wordInList = false;

        }

        static bool CheckNumber(string kata)
        {
            foreach (char karakter in kata)
            {
                if (Char.IsNumber (karakter))
                {
                    return true; 
                }
            }
            return false;
        }

        private void buttonA_Click(object sender, EventArgs e)
        {
            //Button pressedButton = (Button) sender;
            //char pressed = 'a';
            for (int i = 0; i < chosenWord.Length; i++)
            {
                if (chosenWord[i] == 'a')
                {
                    //labelGuess.Text[i] = "a";
                    labelGuess.Text = labelGuess.Text.Remove((i*2), 1);
                    labelGuess.Text = labelGuess.Text.Insert((i*2), 'a'.ToString());

                }
               
            }
            if (chosenWord == labelGuess.Text.Replace(" ", ""))
            {
                MessageBox.Show("YOU WIN !!!");
            }
            //labelGuess.Text = guessed;
            //if (chosenWord.ToLower().Contains('a'))
            //{
            //    for (int i = 0; i < chosenWord.Length; i++)
            //    {
            //        if (chosenWord[i] == pressed)
            //        {
            //            //labelGuess.Text[i] = "a";
            //            i = i * 2;
            //            guessed = labelGuess.Text.Remove(i, 1);
            //            guessed = labelGuess.Text.Insert(i, "a");
            //            //guessed = labelGuess.Text.Replace(labelGuess.Text[i], 'a');

            //            //labelGuess.Text = "halo";
            //        }
            //        //else
            //        //{
            //        //    labelGuess.Text.Replace(labelGuess.Text[i], pressed);
            //        //}
            //    }
            //    labelGuess.Text = guessed;
            //    //Console.WriteLine(guessed);
            //}
        }

        private void buttonQ_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chosenWord.Length; i++)
            {
                if (chosenWord[i] == 'q')
                {
                    labelGuess.Text = labelGuess.Text.Remove((i * 2), 1);
                    labelGuess.Text = labelGuess.Text.Insert((i * 2), 'q'.ToString());
                }
            }
            if (chosenWord == labelGuess.Text.Replace(" ", ""))
            {
                MessageBox.Show("YOU WIN !!!");
            }
        }

        private void buttonW_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chosenWord.Length; i++)
            {
                if (chosenWord[i] == 'w')
                {
                    labelGuess.Text = labelGuess.Text.Remove((i * 2), 1);
                    labelGuess.Text = labelGuess.Text.Insert((i * 2), 'w'.ToString());
                }
            }
            if (chosenWord == labelGuess.Text.Replace(" ", ""))
            {
                MessageBox.Show("YOU WIN !!!");
            }
        }

        private void buttonE_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chosenWord.Length; i++)
            {
                if (chosenWord[i] == 'e')
                {
                    labelGuess.Text = labelGuess.Text.Remove((i * 2), 1);
                    labelGuess.Text = labelGuess.Text.Insert((i * 2), 'e'.ToString());
                }
            }
            if (chosenWord == labelGuess.Text.Replace(" ", ""))
            {
                MessageBox.Show("YOU WIN !!!");
            }
        }

        private void buttonR_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chosenWord.Length; i++)
            {
                if (chosenWord[i] == 'r')
                {
                    labelGuess.Text = labelGuess.Text.Remove((i * 2), 1);
                    labelGuess.Text = labelGuess.Text.Insert((i * 2), 'r'.ToString());
                }
            }
            if (chosenWord == labelGuess.Text.Replace(" ", ""))
            {
                MessageBox.Show("YOU WIN !!!");
            }
        }

        private void buttonT_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chosenWord.Length; i++)
            {
                if (chosenWord[i] == 't')
                {
                    labelGuess.Text = labelGuess.Text.Remove((i * 2), 1);
                    labelGuess.Text = labelGuess.Text.Insert((i * 2), 't'.ToString());
                }
            }
            if (chosenWord == labelGuess.Text.Replace(" ", ""))
            {
                MessageBox.Show("YOU WIN !!!");
            }
        }

        private void buttonY_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chosenWord.Length; i++)
            {
                if (chosenWord[i] == 'y')
                {
                    labelGuess.Text = labelGuess.Text.Remove((i * 2), 1);
                    labelGuess.Text = labelGuess.Text.Insert((i * 2), 'y'.ToString());
                }
            }
            if (chosenWord == labelGuess.Text.Replace(" ", ""))
            {
                MessageBox.Show("YOU WIN !!!");
            }
        }

        private void buttonU_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chosenWord.Length; i++)
            {
                if (chosenWord[i] == 'u')
                {
                    labelGuess.Text = labelGuess.Text.Remove((i * 2), 1);
                    labelGuess.Text = labelGuess.Text.Insert((i * 2), 'u'.ToString());
                }
            }
            if (chosenWord == labelGuess.Text.Replace(" ", ""))
            {
                MessageBox.Show("YOU WIN !!!");
            }
        }

        private void buttonI_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chosenWord.Length; i++)
            {
                if (chosenWord[i] == 'i')
                {
                    labelGuess.Text = labelGuess.Text.Remove((i * 2), 1);
                    labelGuess.Text = labelGuess.Text.Insert((i * 2), 'i'.ToString());
                }
            }
            if (chosenWord == labelGuess.Text.Replace(" ", ""))
            {
                MessageBox.Show("YOU WIN !!!");
            }
        }

        private void buttonO_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chosenWord.Length; i++)
            {
                if (chosenWord[i] == 'o')
                {
                    labelGuess.Text = labelGuess.Text.Remove((i * 2), 1);
                    labelGuess.Text = labelGuess.Text.Insert((i * 2), 'o'.ToString());
                }
            }
            if (chosenWord == labelGuess.Text.Replace(" ", ""))
            {
                MessageBox.Show("YOU WIN !!!");
            }
        }

        private void buttonP_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chosenWord.Length; i++)
            {
                if (chosenWord[i] == 'p')
                {
                    labelGuess.Text = labelGuess.Text.Remove((i * 2), 1);
                    labelGuess.Text = labelGuess.Text.Insert((i * 2), 'p'.ToString());
                }
            }
            if (chosenWord == labelGuess.Text.Replace(" ", ""))
            {
                MessageBox.Show("YOU WIN !!!");
            }
        }

        private void buttonS_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chosenWord.Length; i++)
            {
                if (chosenWord[i] == 's')
                {
                    labelGuess.Text = labelGuess.Text.Remove((i * 2), 1);
                    labelGuess.Text = labelGuess.Text.Insert((i * 2), 's'.ToString());
                }
            }
            if (chosenWord == labelGuess.Text.Replace(" ", ""))
            {
                MessageBox.Show("YOU WIN !!!");
            }
        }

        private void buttonD_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chosenWord.Length; i++)
            {
                if (chosenWord[i] == 'd')
                {
                    labelGuess.Text = labelGuess.Text.Remove((i * 2), 1);
                    labelGuess.Text = labelGuess.Text.Insert((i * 2), 'd'.ToString());
                }
            }
            if (chosenWord == labelGuess.Text.Replace(" ", ""))
            {
                MessageBox.Show("YOU WIN !!!");
            }
        }

        private void buttonF_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chosenWord.Length; i++)
            {
                if (chosenWord[i] == 'f')
                {
                    labelGuess.Text = labelGuess.Text.Remove((i * 2), 1);
                    labelGuess.Text = labelGuess.Text.Insert((i * 2), 'f'.ToString());
                }
            }
            if (chosenWord == labelGuess.Text.Replace(" ", ""))
            {
                MessageBox.Show("YOU WIN !!!");
            }
        }

        private void buttonG_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chosenWord.Length; i++)
            {
                if (chosenWord[i] == 'g')
                {
                    labelGuess.Text = labelGuess.Text.Remove((i * 2), 1);
                    labelGuess.Text = labelGuess.Text.Insert((i * 2), 'g'.ToString());
                }
            }
            if (chosenWord == labelGuess.Text.Replace(" ", ""))
            {
                MessageBox.Show("YOU WIN !!!");
            }
        }

        private void buttonH_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chosenWord.Length; i++)
            {
                if (chosenWord[i] == 'h')
                {
                    labelGuess.Text = labelGuess.Text.Remove((i * 2), 1);
                    labelGuess.Text = labelGuess.Text.Insert((i * 2), 'h'.ToString());
                }
            }
            if (chosenWord == labelGuess.Text.Replace(" ", ""))
            {
                MessageBox.Show("YOU WIN !!!");
            }
        }

        private void buttonJ_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chosenWord.Length; i++)
            {
                if (chosenWord[i] == 'j')
                {
                    labelGuess.Text = labelGuess.Text.Remove((i * 2), 1);
                    labelGuess.Text = labelGuess.Text.Insert((i * 2), 'j'.ToString());
                }
            }
            if (chosenWord == labelGuess.Text.Replace(" ", ""))
            {
                MessageBox.Show("YOU WIN !!!");
            }
        }

        private void buttonK_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chosenWord.Length; i++)
            {
                if (chosenWord[i] == 'k')
                {
                    labelGuess.Text = labelGuess.Text.Remove((i * 2), 1);
                    labelGuess.Text = labelGuess.Text.Insert((i * 2), 'k'.ToString());
                }
            }
            if (chosenWord == labelGuess.Text.Replace(" ", ""))
            {
                MessageBox.Show("YOU WIN !!!");
            }
        }

        private void buttonL_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chosenWord.Length; i++)
            {
                if (chosenWord[i] == 'l')
                {
                    labelGuess.Text = labelGuess.Text.Remove((i * 2), 1);
                    labelGuess.Text = labelGuess.Text.Insert((i * 2), 'l'.ToString());
                }
            }
            if (chosenWord == labelGuess.Text.Replace(" ", ""))
            {
                MessageBox.Show("YOU WIN !!!");
            }
        }

        private void buttonZ_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chosenWord.Length; i++)
            {
                if (chosenWord[i] == 'z')
                {
                    labelGuess.Text = labelGuess.Text.Remove((i * 2), 1);
                    labelGuess.Text = labelGuess.Text.Insert((i * 2), 'z'.ToString());
                }
            }
            if (chosenWord == labelGuess.Text.Replace(" ", ""))
            {
                MessageBox.Show("YOU WIN !!!");
            }
        }

        private void buttonX_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chosenWord.Length; i++)
            {
                if (chosenWord[i] == 'x')
                {
                    labelGuess.Text = labelGuess.Text.Remove((i * 2), 1);
                    labelGuess.Text = labelGuess.Text.Insert((i * 2), 'x'.ToString());
                }
            }
            if (chosenWord == labelGuess.Text.Replace(" ", ""))
            {
                MessageBox.Show("YOU WIN !!!");
            }
        }

        private void buttonC_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chosenWord.Length; i++)
            {
                if (chosenWord[i] == 'c')
                {
                    labelGuess.Text = labelGuess.Text.Remove((i * 2), 1);
                    labelGuess.Text = labelGuess.Text.Insert((i * 2), 'c'.ToString());
                }
            }
            if (chosenWord == labelGuess.Text.Replace(" ", ""))
            {
                MessageBox.Show("YOU WIN !!!");
            }
        }

        private void buttonV_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chosenWord.Length; i++)
            {
                if (chosenWord[i] == 'v')
                {
                    labelGuess.Text = labelGuess.Text.Remove((i * 2), 1);
                    labelGuess.Text = labelGuess.Text.Insert((i * 2), 'v'.ToString());
                }
            }
            if (chosenWord == labelGuess.Text.Replace(" ", ""))
            {
                MessageBox.Show("YOU WIN !!!");
            }
        }

        private void buttonB_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chosenWord.Length; i++)
            {
                if (chosenWord[i] == 'b')
                {
                    labelGuess.Text = labelGuess.Text.Remove((i * 2), 1);
                    labelGuess.Text = labelGuess.Text.Insert((i * 2), 'b'.ToString());
                }
            }
            if (chosenWord == labelGuess.Text.Replace(" ", ""))
            {
                MessageBox.Show("YOU WIN !!!");
            }
        }

        private void buttonN_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chosenWord.Length; i++)
            {
                if (chosenWord[i] == 'n')
                {
                    labelGuess.Text = labelGuess.Text.Remove((i * 2), 1);
                    labelGuess.Text = labelGuess.Text.Insert((i * 2), 'n'.ToString());
                }
            }
            if (chosenWord == labelGuess.Text.Replace(" ", ""))
            {
                MessageBox.Show("YOU WIN !!!");
            }
        }

        private void buttonM_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chosenWord.Length; i++)
            {
                if (chosenWord[i] == 'm')
                {
                    labelGuess.Text = labelGuess.Text.Remove((i * 2), 1);
                    labelGuess.Text = labelGuess.Text.Insert((i * 2), 'm'.ToString());
                }
            }
            if (chosenWord == labelGuess.Text.Replace(" ", ""))
            {
                MessageBox.Show("YOU WIN !!!");
            }
        }
    }
}
